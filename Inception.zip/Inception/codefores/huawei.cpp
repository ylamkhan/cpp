#pragma GCC optimize("Ofast", "unroll-loops", "omit-frame-pointer", "inline")
#pragma GCC option("arch=native", "tune=native", "no-zero-upper")
#pragma GCC target("rdrnd", "popcnt", "avx", "bmi2")

#include <algorithm>
#include <cmath>
#include <iostream>
#include <queue>
#include <set>
#include <string>
#include <vector>
#include <utility>
#include <sys/time.h>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <chrono>

typedef struct s_frame
{
	int frame_id;
    int TBS;
    int user_id;
    int TTIt0j;
    int TTIstdj;

}	t_frame;



void out_put(std::vector<std::vector<std::vector<std::vector<float>>>> &Ptkrn, int N, int K, int T, int R)
{
    for(int t = 0;t < T; t++)
    {
        for(int k = 0; k < K; k++)
        {
            for(int r = 0; r < R; r++)
            {
                for(int n = 0; n < N; n++)
                {
                    std::cout<<Ptkrn[t][k][r][n];
                    if(n != N-1)
                        std::cout<<" ";
                }
                std::cout<<std::endl;
            }
        }
    }
}

void   random_Ptkrn(std::vector<std::vector<std::vector<std::vector<float>>>> &Ptkrn, int N, int K, int T, int R)
{
 
    //float rnd = (float)R/(N*R);
    
    for(int t = 0;t < T; t++)
    {
        for(int k = 0; k < K; k++)
        {
            for(int r = 0; r < R; r++)
            {
                //float frac = ((float)(rand()%(N*T*R*K)))/(N*T*R*T*10);
                for(int n = 0; n < N; n++)
                {
                    // if(n%2==1)
                    //     Ptkrn[t][k][r][n] = (0.1 + frac)*rnd;
                    // else
                    //     Ptkrn[t][k][r][n] =(0.9 - frac)*rnd;
                    if(Ptkrn[t][k][r][n]>=0 && check_R(Ptkrn) && check_N(Ptkrn));
                }
            }
        }
    }
}

void get_Stkrn(std::vector<std::vector<std::vector<std::vector<float>>>> &Stkrn, std::vector<std::vector<std::vector<std::vector<float>>>> &S0tkrn, std::vector<std::vector<std::vector<std::vector<float>>>> &Ptkrn, std::vector<std::vector<std::vector<std::vector<float>>>> &Dkrmn,  int N, int K, int T, int R)
{
    // Stkrn, S0tkrn, Ptkrn, Dkrmn, Btkrn,  N,K,T,R 
    for(int t = 0;t < T; t++)
    {
        for(int k = 0; k < K; k++)
        {
            for(int r = 0; r < R; r++)
            {
                for(int n = 0; n < N; n++)
                {
                    /****************************/
                    float up = S0tkrn[t][k][r][n]*Ptkrn[t][k][r][n];
                    for(int m = 0; m < N; m++)
                    {
                        if(m != n && (Ptkrn[t][k][r][m] != 0))
                            up *= std::exp(Dkrmn[k][r][m][n]);
                    }
                    float down = 1;
                    if(up)
                    {
                        for(int k_ = 0;k_ < K; k_++)
                        {
                            for(int n_ = 0;n_ < N; n_++)
                            {
                                if(n_ != n && k_ != k)
                                    down += S0tkrn[t][k_][r][n]*Ptkrn[t][k_][r][n_]*std::exp(-Dkrmn[k_][r][n_][n]);
                            }
                        }
                    }
                    Stkrn[t][k][r][n] = up/down;
                    /****************************/
                }
            }
        }
    }
}

void get_Stkn_2(std::vector<std::vector<std::vector<float>>> &Stkn_2, std::vector<std::vector<std::vector<std::vector<float>>>> &Stkrn, std::vector<std::vector<std::vector<std::vector<float>>>> &Ptkrn,  int N, int K, int T, int R)
{
    // Stkn_2, Stkrn, Btkrn,  N,K,T,R
    for(int t = 0;t < T; t++)
    {
        for(int k = 0; k < K; k++)
        {
            for(int n = 0; n < N; n++)
            {
                float prod = 1;
                float sum = 0;
                for(int r = 0; r < R; r++)
                {
                    /****************************/
                    if(Ptkrn[t][k][r][n])
                    {
                        prod *= Stkrn[t][k][r][n];
                        sum++;
                    }
                    /****************************/
                    
                }
                Stkn_2[t][k][n] = std::pow(prod, 1/sum);
            }
        }
    }
}


int check_cond(std::vector<std::vector<std::vector<std::vector<float>>>> &Ptkrn, int N, int K, int T, int R)
{
    for(int t = 0;t < T; t++)
    {
        for(int k = 0; k < K; k++)
        {
            int r_sum = 0;
            for(int r = 0; r < R; r++)
            {
                int n_sum = 0;
                for(int n = 0; n < N; n++)
                    n_sum += Ptkrn[t][k][r][n];
                if(n_sum > 4)
                    return 0;
                r_sum += n_sum;
            }
            if(r_sum > R)
                return 0;
        }
    }
    return 1;
}

int scoring_gj(std::vector<t_frame> &frames, std::vector<std::vector<std::vector<std::vector<float>>>> &Ptkrn, std::vector<std::vector<std::vector<float>>> &Stkn_2, int N, int K, int T, int R, int J)
{
    int score = 0;
    for(int j= 0; j< J; j++)
    {
        int t0j = frames[j].TTIt0j;
        int t1j = frames[j].TTIt0j + frames[j].TTIstdj;
        float gj = 0;
        int n = frames[j].user_id;
        for(int t = t0j; t < t1j; t++)
        {
            float k_sum = 0;
            for(int k = 0; k < K; k++)
            {
                float r_sum = 0;
                for(int r = 0; r < R; r++)
                {
                    if(Ptkrn[t][k][r][n])
                        r_sum += std::log2(1+Stkn_2[t][k][n]);
                }
                k_sum += r_sum;
            }
            gj += k_sum;
        }
        score += (gj*192 >= frames[j].TBS);
    }
    return score;
}

int ft_contraints(std::vector<std::vector<std::vector<std::vector<float>>>> &Ptkrn,int R, int N, int T, int K)
{
    float P = 0.0;
    for (int r = 0; r<R ; r++)
    {
        for (int n = 0; n < N; n++)
        {
           P+=Ptkrn[T][R][r][n];
           if(P>R)
                return 0; 
        }
        if(P>R)
            return 0;   
    }
    return 1;
}

int main()
{
    int N,K,T,R,J;
    std::srand(std::time(nullptr));
        std::cin>>N>>K>>T>>R;
        std::vector<std::vector<std::vector<std::vector<float>>>> S0tkrn(T, std::vector<std::vector<std::vector<float>>>(K, std::vector<std::vector<float>>(R, std::vector<float>(N))));
        std::vector<std::vector<std::vector<std::vector<float>>>> Dkrmn(K, std::vector<std::vector<std::vector<float>>>(R, std::vector<std::vector<float>>(N, std::vector<float>(N))));
        
        //std::cout<<N<<K<<T<<R<<std::endl;
        for(int t = 0;t < T; t++)
        {
            for(int k = 0; k < K; k++)
            {
                for(int r = 0; r < R; r++)
                {
                    for(int n = 0; n < N; n++)
                        std::cin>>S0tkrn[t][k][r][n];
                }
            }
        }
        //std::cout<<S0tkrn[0][0][0][0]<<std::endl;
        for(int k = 0; k < K; k++)
        {
            for(int r = 0; r < R; r++)
            {
                for(int m = 0; m < N; m++)
                {
                    for(int n = 0; n < N; n++)
                        std::cin>>Dkrmn[k][r][m][n];
                }
            }
        }
        std::cin>>J;
        std::vector<t_frame> frames(J);
        for(int j = 0; j < J; j++)
        {
            std::cin>>frames[j].frame_id>>frames[j].TBS>>frames[j].user_id>>frames[j].TTIt0j>>frames[j].TTIstdj;
        }
        
        auto start_time = std::chrono::high_resolution_clock::now();
        
        
        
        /***************************************/
        std::vector<std::vector<std::vector<std::vector<float>>>> Ptkrn(T, std::vector<std::vector<std::vector<float>>>(K, std::vector<std::vector<float>>(R, std::vector<float>(N))));
        //std::vector<std::vector<std::vector<std::vector<float>>>> Btkrn(T, std::vector<std::vector<std::vector<float>>>(K, std::vector<std::vector<float>>(R, std::vector<float>(N))));
        //std::vector<std::vector<std::vector<std::vector<float>>>> Stkrn(T, std::vector<std::vector<std::vector<float>>>(K, std::vector<std::vector<float>>(R, std::vector<float>(N))));
        std::vector<std::vector<std::vector<float>>> Stkn_2(T, std::vector<std::vector<float>>(K, std::vector<float>(N)));
        std::vector<std::vector<std::vector<std::vector<float>>>> save_Ptkrn(T, std::vector<std::vector<std::vector<float>>>(K, std::vector<std::vector<float>>(R, std::vector<float>(N))));
        
      
        //random_Ptkrn(Ptkrn, N,K,T,R);
        //check_cond(Ptkrn,  N,K,T,R)
        //get_Stkrn(Stkrn, S0tkrn, Ptkrn, Dkrmn, N,K,T,R);
        //get_Stkn_2(Stkn_2, Stkrn, Ptkrn,  N,K,T,R);
        //scoring_gj(frames, Ptkrn, Stkn_2,  N,K,T,R, J);
        //int old_score;
        //random_Ptkrn(save_Ptkrn, N,K,T,R);
        //get_Stkrn(Stkrn, S0tkrn, save_Ptkrn, Dkrmn, N,K,T,R);
        //get_Stkn_2(Stkn_2, Stkrn, Ptkrn,  N,K,T,R);
        //old_score = scoring_gj(frames, Ptkrn, Stkn_2,  N,K,T,R, J);


       
        //int turn = 0;
        //while(++turn < 200)
        //{
            //random_Ptkrn(Ptkrn, N,K,T,R);
            //save_Ptkrn = Ptkrn;
            //get_Stkrn(Stkrn, S0tkrn, Ptkrn, Dkrmn, N,K,T,R);
            //get_Stkn_2(Stkn_2, Stkrn, Ptkrn,  N,K,T,R);

            //int score = scoring_gj(frames, Ptkrn, Stkn_2,  N,K,T,R, J);
            //  if(score >= old_score)
            //  {
            //      save_Ptkrn = Ptkrn;
            //      old_score = score;
            //  }
            
            
            
        //}
        //usleep(1600*1000);;



    //out_put(save_Ptkrn, N,K,T,R);
    //std::cout<<"turn = "<<turn<<" score = "<<old_score<<" time = "<<timeNow() - startMs<<std::endl;
   
}