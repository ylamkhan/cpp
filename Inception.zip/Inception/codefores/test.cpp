#include <iostream>
#include <vector>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <new>
#include <cstring>

using namespace std;

int main()
{
    int n;
    vector <int> d;
    cin>>n;
    while (n--)
    {
        int s;
        d.push_back(s);
        
    }
    
    return 0;
}
