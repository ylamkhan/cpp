#include<iostream>
#include<vector>
#include<map>

// typedef struct  fram
// {
//     int id_frame;
//     int TBS;
//     int id_usr;
//     int TTI;
//     int TTIs;
// }t_data;


int output(int f)
{
    if()
}

using namespace std;
int main()
{
    int N;
    int K;
    int T;
    int R;
    int S[T][K][R][N];
    int D[K][R][N][N];
    int J;
    int id_frame[J];
    int TBS[J];
    int id_usr[J];
    int TTI[J];
    int TTIs[J];
    float P[T][K][R][N];


    /*data N K T R*/
    cin>>N>>K>>T>>R;

    /*data s*/

    for (int t = 0; t < T; t++)
    {
        for (int k = 0; k < K; k++)
        {
            for (int r = 0; r < R; r++)
            {
                for (int n = 0; n < N; n++)
                {
                    cin>>S[t][k][r][n];
                }
                
            }
            
        }
        
    }

    for (int k = 0; k < K; k++)
    {
        for (int r = 0; r < R; r++)
        {
            for (int m = 0; m < N; m++)
            {
                for (int n = 0; n < N; n++)
                {
                    cin>>D[k][r][m][n];
                }
            }
            
        }
        
    }
    cin>>J;
    for (int j = 0; j < J; j++)
    {
        cin>>TBS[j]>>id_usr[j]>>TTI[j]>>TTIs[j];
    }

    float P[T][K][R][N];

    for (int t = 0; t < T; t++)
    {
        for (int k = 0; k < K; k++)
        {
            for (int r = 0; r < R; r++)
            {
                for (int n = 0; n < N; n++)
                {
                    if()
                }
            }
            
        }
        
    }




}

