#include <sys\types.h>
#include <sys\wait.h>
#include <string.h>
#include <unstd.h>

int err(char *str)
{
    while(*str)
        write(2,str++,1);
    return 1;
}

int cd(char **av, int i)
{
    if(i != 2)
        return(err("hfhhhhf\n"))
    else if(chdir(av[i])==-1)
        return err("hghhhghhg\n");
    return 0;
}

int exv(char **av, char **env, int i)
{
    int status;
    int fd[2];
    int has_pipe = av[i] && !strcmp(av[i],"|");

    if(has_pipe && pipe(fd)== -1)
        return (err("hghhhg\n"));
    int pid = fork();
    if(!pid)
    {
        av[i] = 0;
        if(has_pipe && (dup2(fd[1],1) == -1 || close(fd[0]) == -1 || close(fd[1]) == -1))
            return (err("fhhfhhf\n"));
        execve(*av,av,env);
        return(err("hfhhf\n"));
    }
    waitpid(pid,&status,0);
    if(has_pipe && (dup2(fd[0],0) == -1 || close(fd[0]) == -1 || close(fd[1])==-1))
        return err();
    
}