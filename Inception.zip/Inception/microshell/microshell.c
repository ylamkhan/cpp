#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <stdio.h>

int err(char *str) 
{
    while (*str)
        write(2, str++, 1);
    return 1;
}

int command_cd(char **av, int i) 
{
    if (i != 2)
        return err("error:\n");
    else if (chdir(av[1]) == -1)
        return err("error:"), err(av[1]), err("\n");
    return 0;
}

int command_pipe_point(char **av, char **env, int i) 
{
    int fd[2];
    int status;
    int has_pipe = av[i] && !strcmp(av[i], "|");

    if (has_pipe && pipe(fd) == -1)
        return err("error\n");

    int pid = fork();
    if (!pid) 
    {
        av[i] = 0;
        if (has_pipe && (dup2(fd[1], 1) == -1 || close(fd[0]) == -1 || close(fd[1]) == -1))
            return err("error:\n");
        execve(*av, av, env);
        return err("error:"), err(*av), err("\n");
    }

    waitpid(pid, &status, 0);
    if (has_pipe && (dup2(fd[0], 0) == -1 || close(fd[0]) == -1 || close(fd[1]) == -1))
        return err("error:\n");
    return WIFEXITED(status) && WEXITSTATUS(status);
}

int main(int ac, char **av, char **env) 
{
    int    i = 0;
    int    exit_status = 0;

    if (ac > 1) 
    {
        while (av[i] && av[++i]) 
        {
            av += i;
            i = 0;
            while (av[i] && strcmp(av[i], "|") && strcmp(av[i], ";"))
                i++;
            if (!strcmp(*av, "cd"))
                exit_status = command_cd(av, i);
            else if (i)
                exit_status = command_pipe_point(av, env, i);
        }
    }
    return exit_status;
}

