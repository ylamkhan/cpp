# include <sys/wait.h>
# include <sys/types.h>
# include <unistd.h>


void err(char *str)
{
    while (*str)
        write(2,str++,1);   
}

int main(int ac, char **av, char **env)
{
    if(ac>1)
    {
        int status = 0;
        int i = 1;
        while(av[i]&& !strcmp(av[i],"|"))
    }
}